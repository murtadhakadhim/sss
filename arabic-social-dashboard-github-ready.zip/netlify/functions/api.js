const serverless = require('serverless-http');
const { app } = require('../../server-build/src/server/app.js');

exports.handler = serverless(app);

import { createCipheriv, randomBytes, timingSafeEqual } from 'node:crypto';
import type { Express, RequestHandler } from 'express';
import { and, eq } from 'drizzle-orm';
import { env } from '../config/env.js';
import { db, OWNER_ID } from '../database/client.js';
import { oauthCredentials, owners, socialAccounts } from '../database/schema.js';

type Provider = 'facebook' | 'instagram' | 'tiktok';
type OAuthConfig = { clientId: string; clientSecret: string; redirectUri: string };
const oauthConfig = (provider: Provider): OAuthConfig | undefined => {
  if (provider === 'facebook' && env.FACEBOOK_APP_ID && env.FACEBOOK_APP_SECRET && env.FACEBOOK_REDIRECT_URI) return { clientId: env.FACEBOOK_APP_ID, clientSecret: env.FACEBOOK_APP_SECRET, redirectUri: env.FACEBOOK_REDIRECT_URI };
  if (provider === 'instagram' && env.INSTAGRAM_APP_ID && env.INSTAGRAM_APP_SECRET && env.INSTAGRAM_REDIRECT_URI) return { clientId: env.INSTAGRAM_APP_ID, clientSecret: env.INSTAGRAM_APP_SECRET, redirectUri: env.INSTAGRAM_REDIRECT_URI };
  if (provider === 'tiktok' && env.TIKTOK_CLIENT_KEY && env.TIKTOK_CLIENT_SECRET && env.TIKTOK_REDIRECT_URI) return { clientId: env.TIKTOK_CLIENT_KEY, clientSecret: env.TIKTOK_CLIENT_SECRET, redirectUri: env.TIKTOK_REDIRECT_URI };
};
const keyBytes = () => {
  const value = env.TOKEN_ENCRYPTION_KEY ?? '';
  const key = /^[0-9a-f]{64}$/i.test(value) ? Buffer.from(value, 'hex') : Buffer.from(value, 'base64');
  if (key.length !== 32) throw new Error('TOKEN_ENCRYPTION_KEY must encode exactly 32 random bytes');
  return key;
};
const encrypt = (value: string) => {
  const iv = randomBytes(12), cipher = createCipheriv('aes-256-gcm', keyBytes(), iv);
  const data = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
  return [iv, cipher.getAuthTag(), data].map(part => part.toString('base64url')).join('.');
};
const getJson = async (url: URL, headers?: Record<string, string>) => {
  const response = await fetch(url, { headers });
  const body = await response.json().catch(() => ({})) as any;
  const providerError = typeof body.error === 'string' ? body.error && body.error !== 'ok' : body.error?.code && body.error.code !== 'ok';
  if (!response.ok || providerError) throw new Error('Provider request failed');
  return body;
};
const postForm = async (url: string, fields: Record<string, string>) => {
  const response = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(fields) });
  const body = await response.json().catch(() => ({})) as any;
  const providerError = typeof body.error === 'string' ? body.error && body.error !== 'ok' : body.error?.code && body.error.code !== 'ok';
  if (!response.ok || providerError || body.error_description) throw new Error('Provider token exchange failed');
  return body;
};
const saveAccount = async (input: { provider: Provider; providerId: string; name: string; username?: string; accessToken: string; refreshToken?: string; expiresIn?: number; scopes: string[]; accountType: string }) => {
  const [owner] = await db.select({ email: owners.email }).from(owners).where(eq(owners.id, OWNER_ID));
  if (!owner) throw new Error('Owner account is not initialized');
  const [existing] = await db.select({ id: socialAccounts.id }).from(socialAccounts).where(and(eq(socialAccounts.ownerId, OWNER_ID), eq(socialAccounts.platform, input.provider), eq(socialAccounts.platformAccountId, input.providerId)));
  const values = { displayName: input.name.slice(0, 120), username: input.username?.slice(0, 120), accountType: input.accountType, connectionMethod: 'oauth', connectionStatus: 'connected' as const, platformAccountId: input.providerId, grantedPermissions: input.scopes, supportedCapabilities: input.scopes, lastVerifiedAt: new Date(), updatedAt: new Date() };
  const [account] = existing
    ? await db.update(socialAccounts).set(values).where(eq(socialAccounts.id, existing.id)).returning({ id: socialAccounts.id })
    : await db.insert(socialAccounts).values({ ...values, ownerId: OWNER_ID, platform: input.provider }).returning({ id: socialAccounts.id });
  const credential = { socialAccountId: account.id, encryptedAccessToken: encrypt(input.accessToken), encryptedRefreshToken: input.refreshToken ? encrypt(input.refreshToken) : null, encryptionVersion: 'aes-256-gcm-v1', expiresAt: input.expiresIn ? new Date(Date.now() + input.expiresIn * 1000) : null, scopes: input.scopes };
  await db.insert(oauthCredentials).values(credential).onConflictDoUpdate({ target: oauthCredentials.socialAccountId, set: { encryptedAccessToken: credential.encryptedAccessToken, encryptedRefreshToken: credential.encryptedRefreshToken, encryptionVersion: credential.encryptionVersion, expiresAt: credential.expiresAt, scopes: credential.scopes } });
};
const takeOAuthState = (req: any, provider: Provider, returnedState: string) => {
  const pending = req.session.oauthPending;
  delete req.session.oauthPending;
  if (!pending || pending.provider !== provider || typeof pending.state !== 'string' || typeof returnedState !== 'string') return false;
  const a = Buffer.from(pending.state), b = Buffer.from(returnedState);
  return a.length === b.length && timingSafeEqual(a, b);
};

export function registerOAuthRoutes(app: Express, auth: RequestHandler) {
  const providers: Provider[] = ['facebook', 'instagram', 'tiktok'];
  app.get('/api/oauth/:provider/start', auth, (req, res) => {
    const provider = req.params.provider as Provider;
    if (!providers.includes(provider)) return res.status(404).json({ error: 'المنصة غير مدعومة' });
    const config = oauthConfig(provider);
    if (!config || !env.TOKEN_ENCRYPTION_KEY) return res.status(503).json({ error: 'إعداد مفاتيح التطبيق أو تشفير الرموز غير مكتمل في Netlify.' });
    const state = randomBytes(32).toString('base64url');
    (req.session as any).oauthPending = { provider, state };
    let authorize: URL;
    if (provider === 'facebook') {
      authorize = new URL(`https://www.facebook.com/${env.META_GRAPH_VERSION}/dialog/oauth`);
      authorize.search = new URLSearchParams({ client_id: config.clientId, redirect_uri: config.redirectUri, response_type: 'code', scope: 'pages_show_list,pages_read_engagement,pages_manage_posts,pages_read_user_content,pages_manage_engagement', state }).toString();
    } else if (provider === 'instagram') {
      authorize = new URL('https://www.instagram.com/oauth/authorize');
      authorize.search = new URLSearchParams({ client_id: config.clientId, redirect_uri: config.redirectUri, response_type: 'code', scope: 'instagram_business_basic,instagram_business_manage_comments,instagram_business_content_publish', state }).toString();
    } else {
      authorize = new URL('https://www.tiktok.com/v2/auth/authorize/');
      authorize.search = new URLSearchParams({ client_key: config.clientId, redirect_uri: config.redirectUri, response_type: 'code', scope: 'user.info.basic,video.list,video.publish,video.upload', state }).toString();
    }
    res.redirect(authorize.toString());
  });

  for (const provider of providers) app.get(`/api/oauth/${provider}/callback`, async (req, res) => {
    const config = oauthConfig(provider);
    try {
      if (!config || !env.TOKEN_ENCRYPTION_KEY) throw new Error('Integration is not configured');
      if (req.query.error) throw new Error('Authorization was declined');
      if (!takeOAuthState(req, provider, String(req.query.state ?? ''))) return res.status(400).redirect(`${env.APP_URL}/?oauth=${provider}&status=state_error`);
      const code = String(req.query.code ?? '');
      if (!code || code.length > 2048) return res.status(400).redirect(`${env.APP_URL}/?oauth=${provider}&status=code_error`);

      if (provider === 'facebook') {
        const tokenUrl = new URL(`https://graph.facebook.com/${env.META_GRAPH_VERSION}/oauth/access_token`);
        tokenUrl.search = new URLSearchParams({ client_id: config.clientId, client_secret: config.clientSecret, redirect_uri: config.redirectUri, code }).toString();
        const shortToken = await getJson(tokenUrl);
        const longUrl = new URL(`https://graph.facebook.com/${env.META_GRAPH_VERSION}/oauth/access_token`);
        longUrl.search = new URLSearchParams({ grant_type: 'fb_exchange_token', client_id: config.clientId, client_secret: config.clientSecret, fb_exchange_token: shortToken.access_token }).toString();
        const longToken = await getJson(longUrl);
        const permissionUrl = new URL(`https://graph.facebook.com/${env.META_GRAPH_VERSION}/me/permissions`);
        permissionUrl.searchParams.set('access_token', longToken.access_token ?? shortToken.access_token);
        const permissionData = await getJson(permissionUrl);
        const grantedScopes = (permissionData.data ?? []).filter((permission: any) => permission.status === 'granted').map((permission: any) => String(permission.permission));
        const pagesUrl = new URL(`https://graph.facebook.com/${env.META_GRAPH_VERSION}/me/accounts`);
        pagesUrl.search = new URLSearchParams({ fields: 'id,name,access_token,tasks', access_token: longToken.access_token ?? shortToken.access_token }).toString();
        const pages = await getJson(pagesUrl);
        const allowed = (pages.data ?? []).filter((page: any) => page.id && page.access_token);
        if (!allowed.length) throw new Error('No eligible Pages were granted');
        for (const page of allowed) await saveAccount({ provider, providerId: String(page.id), name: String(page.name || 'Facebook Page'), accessToken: String(page.access_token), expiresIn: longToken.expires_in, scopes: grantedScopes, accountType: 'facebook_page' });
      } else if (provider === 'instagram') {
        const shortToken = await postForm('https://api.instagram.com/oauth/access_token', { client_id: config.clientId, client_secret: config.clientSecret, grant_type: 'authorization_code', redirect_uri: config.redirectUri, code });
        const longUrl = new URL('https://graph.instagram.com/access_token');
        longUrl.search = new URLSearchParams({ grant_type: 'ig_exchange_token', client_secret: config.clientSecret, access_token: shortToken.access_token }).toString();
        const longToken = await getJson(longUrl);
        const profileUrl = new URL('https://graph.instagram.com/me');
        profileUrl.search = new URLSearchParams({ fields: 'user_id,username,account_type', access_token: longToken.access_token ?? shortToken.access_token }).toString();
        const profile = await getJson(profileUrl);
        await saveAccount({ provider, providerId: String(profile.user_id ?? profile.id), name: String(profile.username || 'Instagram Professional'), username: String(profile.username || ''), accessToken: String(longToken.access_token ?? shortToken.access_token), expiresIn: longToken.expires_in, scopes: String(shortToken.permissions ?? 'instagram_business_basic,instagram_business_manage_comments,instagram_business_content_publish').split(','), accountType: String(profile.account_type || 'instagram_professional') });
      } else {
        const token = await postForm('https://open.tiktokapis.com/v2/oauth/token/', { client_key: config.clientId, client_secret: config.clientSecret, code, grant_type: 'authorization_code', redirect_uri: config.redirectUri });
        const profileUrl = new URL('https://open.tiktokapis.com/v2/user/info/');
        profileUrl.searchParams.set('fields', 'open_id,display_name,avatar_url');
        const profile = await getJson(profileUrl, { Authorization: `Bearer ${token.access_token}` });
        const info = profile.data?.user ?? {};
        await saveAccount({ provider, providerId: String(token.open_id ?? info.open_id), name: String(info.display_name || 'TikTok'), username: String(info.display_name || ''), accessToken: String(token.access_token), refreshToken: token.refresh_token ? String(token.refresh_token) : undefined, expiresIn: Number(token.expires_in) || undefined, scopes: String(token.scope ?? '').split(',').filter(Boolean), accountType: 'tiktok_user' });
      }
      res.redirect(`${env.APP_URL}/?oauth=${provider}&status=connected`);
    } catch (error) {
      console.error(`OAuth callback failed for ${provider}:`, error instanceof Error ? error.message : 'unknown');
      res.redirect(`${env.APP_URL}/?oauth=${provider}&status=failed`);
    }
  });
}

import{getConnectionString}from'@netlify/database';import{Pool}from'pg';import{drizzle}from'drizzle-orm/node-postgres';import{env}from'../config/env.js';import*as schema from'./schema.js';
export const databaseUrl=env.DATABASE_URL??env.NETLIFY_DB_URL??getConnectionString();
export const pool=new Pool({connectionString:databaseUrl,ssl:env.NODE_ENV==='production'?{rejectUnauthorized:false}:undefined,max:3,idleTimeoutMillis:10000,connectionTimeoutMillis:10000});
export const db=drizzle(pool,{schema});
export const OWNER_ID='00000000-0000-4000-8000-000000000001';

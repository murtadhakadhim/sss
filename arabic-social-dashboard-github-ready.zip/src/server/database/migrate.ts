import'dotenv/config';import{readFile}from'node:fs/promises';import{pool}from'./client.js';
try{const migration=await readFile(new URL('./migrations/0001_initial.sql',import.meta.url),'utf8');await pool.query(migration);console.log('Database migration applied.')}finally{await pool.end()}

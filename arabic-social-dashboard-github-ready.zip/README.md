# Arabic Social Account Dashboard

Single-owner Arabic RTL dashboard for social account metadata and comment drafts.

## Local development

Requirements: Node.js 22.12+ and PostgreSQL 14+.

1. Run `npm install`.
2. Copy `.env.example` to `.env` and set `DATABASE_URL`, `OWNER_EMAIL`, `OWNER_PASSWORD_HASH`, and a random 32+ character `SESSION_SECRET`.
3. Generate the password hash with `node -e "import('argon2').then(async a=>console.log(await a.hash(process.argv[1])))" "your-password"`.
4. Run `npm run db:migrate` once against the configured database.
5. Run `npm run dev`.

`npm run build` runs TypeScript checking and creates the Vite site in `dist`. `npm run test` runs URL validation tests. `npm run start` starts Express for a standalone Node deployment.

## Netlify deployment

The repository includes a Netlify Functions wrapper for Express, a `/api/*` rewrite, and a PostgreSQL migration under `netlify/database/migrations/`. The `@netlify/database` dependency lets Netlify provision its integrated PostgreSQL database and apply the migration when the project is linked and deployed.

Connect this folder through a Git repository in Netlify. In the Netlify dashboard, configure these runtime variables before publishing:

- `APP_URL`: exact public origin, for example `https://your-site.netlify.app`.
- `SESSION_SECRET`: at least 32 random characters.
- `OWNER_EMAIL` and `OWNER_PASSWORD_HASH`: the single owner's email and Argon2id password hash.
- `NODE_ENV=production`.
- `GEMINI_API_KEY` (optional) and `GEMINI_MODEL` (optional, defaults to `gemini-2.5-flash`).
- `TOKEN_ENCRYPTION_KEY`: a secret encoding exactly 32 random bytes (base64 or 64-character hex); it encrypts provider tokens before they are stored in PostgreSQL.
- Facebook Login: `FACEBOOK_APP_ID`, `FACEBOOK_APP_SECRET`, `FACEBOOK_REDIRECT_URI`.
- Instagram Login: `INSTAGRAM_APP_ID`, `INSTAGRAM_APP_SECRET`, `INSTAGRAM_REDIRECT_URI`.
- TikTok Login Kit: `TIKTOK_CLIENT_KEY`, `TIKTOK_CLIENT_SECRET`, `TIKTOK_REDIRECT_URI`.
- `META_GRAPH_VERSION` (optional, defaults to `v26.0`).

Netlify Database is available on credit-based plans and database compute/bandwidth consume credits. Confirm the plan and expected usage in Netlify before enabling/publishing the database. Netlify's migration system applies files in `netlify/database/migrations/` during deploy. Keep owner credentials, session secrets, and Gemini keys in the dashboard; never commit them or expose them as `VITE_` variables.

Build command: `npm run build`. Publish directory: `dist`. Functions directory: `netlify/functions` (configured in `netlify.toml`).

## Security and integration limits

Only one owner is supported. Login uses PostgreSQL-backed sessions, rate limiting, HTTP-only SameSite cookies, production Secure cookies, and same-origin checks for state-changing requests. Accounts and drafts persist in PostgreSQL. Manual social records are metadata only and cannot execute operations. The application never fetches arbitrary post URLs.

OAuth authorization is implemented for Facebook Pages, Instagram professional accounts, and TikTok accounts. Each flow checks a one-time CSRF state value and encrypts stored OAuth tokens with `TOKEN_ENCRYPTION_KEY`. Register these exact callback URLs in each provider app:

- `https://your-site.netlify.app/api/oauth/facebook/callback`
- `https://your-site.netlify.app/api/oauth/instagram/callback`
- `https://your-site.netlify.app/api/oauth/tiktok/callback`

Provider app review and granted scopes remain required. OAuth connection stores the authorized accounts and tokens, but the app does not yet publish posts or reply to comments through provider APIs. TikTok's `video.publish` access also requires platform approval and audit for public posting. The Gemini draft endpoint is implemented but requires a server-side `GEMINI_API_KEY`. No provider integration has been tested until credentials are configured and an account completes OAuth.

import { defineConfig } from 'drizzle-kit';
export default defineConfig({schema:'./src/server/database/schema.ts',out:'./netlify/database/migrations',dialect:'postgresql',dbCredentials:{url:process.env.DATABASE_URL??process.env.NETLIFY_DB_URL??''}});

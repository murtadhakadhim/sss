# رفع المشروع إلى GitHub ثم ربطه بـ Netlify

1. أنشئ مستودعاً فارغاً في GitHub. لا تضف README أو `.gitignore` من GitHub لأن ملفات المشروع موجودة هنا.
2. افتح PowerShell داخل مجلد المشروع بعد فك ضغط الحزمة.
3. نفّذ الأوامر التالية، مع استبدال الرابط برابط مستودعك:

```powershell
git init
git add .
git status --short
# تأكد أن .env ومجلدات .netlify و.netlify-home غير موجودة في قائمة الملفات
git commit -m "Initial project upload"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```

4. في Netlify اختر **Add new project → Import an existing project → GitHub**، ثم اختر المستودع واضبط أمر البناء `npm run build` ومجلد النشر `dist`.
5. أبقِ مفاتيح المنصات وGemini وبيانات الدخول في **Netlify Environment variables** فقط؛ لا تحفظها في GitHub. احتفظ بقيم إعدادات Netlify الحالية عند الربط بالمستودع.

يتطلب المشروع Node.js 22.12+، وتعليمات PostgreSQL والإعدادات موجودة في `README.md` و`.env.example`.
